# Labeled trees, Pruefer sequences, and spanning-tree counts, from
# scratch in base R. A graph is an m x 2 integer matrix of edges on
# vertices 1..n. Three independent ways of counting spanning trees are
# implemented so they can be checked against each other:
#   (1) brute force over edge subsets,
#   (2) the Matrix-Tree theorem (a determinant),
#   (3) the product of the nonzero Laplacian eigenvalues, divided by n.

# ---- union-find, forests, trees ----------------------------------------

#' TRUE if the given edges contain no cycle (union-find).
is_forest <- function(edges, n) {
  parent <- seq_len(n)
  find <- function(v) { while (parent[v] != v) v <- parent[v]; v }
  for (i in seq_len(nrow(edges))) {
    a <- find(edges[i, 1]); b <- find(edges[i, 2])
    if (a == b) return(FALSE)
    parent[a] <- b
  }
  TRUE
}

#' A graph on n vertices is a tree iff it has n - 1 edges and no cycle.
is_tree <- function(edges, n) nrow(edges) == n - 1 && is_forest(edges, n)

#' Canonical string for an edge set, so equal trees get equal keys.
tree_key <- function(edges) {
  e <- apply(edges, 1, function(r) paste(min(r), max(r)))
  paste(sort(e), collapse = ";")
}

# ---- Pruefer encoding and decoding ------------------------------------

#' Encode a labeled tree as a Pruefer sequence, recording each step.
#' Repeat n - 2 times: remove the SMALLEST current leaf and write down
#' the label of its (unique) neighbour.
prufer_encode_trace <- function(edges, n) {
  adj <- vector("list", n)
  for (i in seq_len(nrow(edges))) {
    a <- edges[i, 1]; b <- edges[i, 2]
    adj[[a]] <- c(adj[[a]], b); adj[[b]] <- c(adj[[b]], a)
  }
  deg <- vapply(adj, length, numeric(1))
  removed <- logical(n)
  leaf <- integer(max(n - 2, 0)); neighbour <- integer(max(n - 2, 0))
  for (i in seq_len(n - 2)) {
    l <- min(which(deg == 1 & !removed))
    nb <- adj[[l]][!removed[adj[[l]]]]
    leaf[i] <- l; neighbour[i] <- nb
    removed[l] <- TRUE; deg[l] <- 0; deg[nb] <- deg[nb] - 1
  }
  data.frame(step = seq_along(leaf), leaf = leaf, neighbour = neighbour)
}

prufer_encode <- function(edges, n) prufer_encode_trace(edges, n)$neighbour

#' Decode a Pruefer sequence (length n - 2, entries in 1..n) into the
#' unique tree that produced it. Vertex v starts with degree
#' 1 + (number of times v appears in the sequence); at each step the
#' smallest vertex of degree 1 (a leaf) is joined to the next entry.
prufer_decode <- function(s) {
  n <- length(s) + 2
  deg <- 1 + tabulate(s, nbins = n)
  edges <- matrix(0L, n - 1, 2)
  for (i in seq_along(s)) {
    leaf <- min(which(deg == 1))
    edges[i, ] <- c(leaf, s[i])
    deg[leaf] <- 0
    deg[s[i]] <- deg[s[i]] - 1
  }
  edges[n - 1, ] <- which(deg == 1)        # the last two vertices are joined
  edges
}

# ---- Laplacian and spanning-tree counts --------------------------------

#' Graph Laplacian L = D - A.
laplacian <- function(edges, n) {
  L <- matrix(0, n, n)
  for (i in seq_len(nrow(edges))) {
    a <- edges[i, 1]; b <- edges[i, 2]
    L[a, a] <- L[a, a] + 1; L[b, b] <- L[b, b] + 1
    L[a, b] <- L[a, b] - 1; L[b, a] <- L[b, a] - 1
  }
  L
}

#' Matrix-Tree theorem: any cofactor of L counts the spanning trees.
count_trees_determinant <- function(edges, n) round(det(laplacian(edges, n)[-1, -1, drop = FALSE]))

#' Eigenvalue form: (product of the n - 1 largest Laplacian eigenvalues) / n.
count_trees_eigen <- function(edges, n) {
  ev <- eigen(laplacian(edges, n), symmetric = TRUE, only.values = TRUE)$values
  round(prod(ev[seq_len(n - 1)]) / n)
}

#' Brute force: an (n-1)-edge subset is a spanning tree iff acyclic.
count_trees_brute <- function(edges, n) {
  if (nrow(edges) < n - 1) return(0)
  hits <- combn(nrow(edges), n - 1, FUN = function(idx) is_forest(edges[idx, , drop = FALSE], n))
  sum(hits)
}

# ---- graph constructors --------------------------------------------------

complete_graph <- function(n) t(combn(n, 2))
complete_bipartite <- function(a, b) as.matrix(expand.grid(1:a, a + 1:b))
cycle_graph <- function(n) cbind(1:n, c(2:n, 1))
grid_graph <- function(r, c) {
  id <- function(i, j) (i - 1) * c + j
  e <- NULL
  for (i in 1:r) for (j in 1:c) {
    if (j < c) e <- rbind(e, c(id(i, j), id(i, j + 1)))
    if (i < r) e <- rbind(e, c(id(i, j), id(i + 1, j)))
  }
  e
}
petersen_graph <- function() rbind(cbind(1:5, c(2:5, 1)), cbind(1:5, 6:10),
                                   cbind(6:10, c(8, 9, 10, 6, 7)))

is_connected <- function(edges, n) {
  parent <- seq_len(n)
  find <- function(v) { while (parent[v] != v) v <- parent[v]; v }
  for (i in seq_len(nrow(edges))) parent[find(edges[i, 1])] <- find(edges[i, 2])
  length(unique(vapply(seq_len(n), find, numeric(1)))) == 1
}

random_connected_graph <- function(n, p) {
  all_edges <- complete_graph(n)
  repeat {
    keep <- runif(nrow(all_edges)) < p
    if (sum(keep) >= n - 1 && is_connected(all_edges[keep, , drop = FALSE], n)) {
      return(all_edges[keep, , drop = FALSE])
    }
  }
}
