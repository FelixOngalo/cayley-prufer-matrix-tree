library(dplyr)
library(tibble)
source("R/graph_functions.R")
set.seed(42)

# ---------------------------------------------------------------------
cat("=== 1. Pruefer sequences are a bijection: all sequences, n = 3..7 ===\n")
# For EVERY sequence in {1..n}^(n-2): decode it, check the result is a
# tree, encode it back, and compare. Then count distinct trees.
prufer_check <- bind_rows(lapply(3:7, function(n) {
  seqs <- as.matrix(expand.grid(rep(list(1:n), n - 2)))
  keys <- character(nrow(seqs)); valid <- logical(nrow(seqs))
  roundtrip <- logical(nrow(seqs)); deg_ok <- logical(nrow(seqs))
  for (i in seq_len(nrow(seqs))) {
    s <- unname(seqs[i, ])
    edges <- prufer_decode(s)
    keys[i] <- tree_key(edges)
    valid[i] <- is_tree(edges, n)
    roundtrip[i] <- identical(as.integer(prufer_encode(edges, n)), as.integer(s))
    deg <- tabulate(c(edges), nbins = n)
    deg_ok[i] <- all(deg - 1 == tabulate(s, nbins = n))      # Lemma: v appears deg(v) - 1 times
  }
  tibble(n = n, sequences = nrow(seqs), cayley_n_pow_n_minus_2 = n^(n - 2),
         distinct_trees_decoded = length(unique(keys)),
         decoded_not_a_tree = sum(!valid), encode_decode_failures = sum(!roundtrip),
         degree_lemma_violations = sum(!deg_ok))
}))
print(prufer_check)

cat("\n=== 2. The other direction, with NO use of Cayley's formula: enumerate every labeled tree by brute force ===\n")
# All (n-1)-edge subsets of K_n that are acyclic ARE the labeled trees.
# Encode each; the sequences must be distinct, and decoding must return the same tree.
enum_check <- bind_rows(lapply(3:6, function(n) {
  kn <- complete_graph(n)
  subsets <- combn(nrow(kn), n - 1, simplify = FALSE)
  trees <- Filter(function(idx) is_forest(kn[idx, , drop = FALSE], n), subsets)
  seq_keys <- vapply(trees, function(idx) paste(prufer_encode(kn[idx, , drop = FALSE], n), collapse = ","), character(1))
  back_ok <- vapply(trees, function(idx) {
    e <- kn[idx, , drop = FALSE]
    tree_key(prufer_decode(prufer_encode(e, n))) == tree_key(e)
  }, logical(1))
  tibble(n = n, trees_found_by_brute_force = length(trees), n_pow_n_minus_2 = n^(n - 2),
         distinct_pruefer_sequences = length(unique(seq_keys)), decode_encode_failures = sum(!back_ok))
}))
print(enum_check)

# ---------------------------------------------------------------------
cat("\n=== 3. Matrix-Tree theorem: three independent spanning-tree counts ===\n")
graphs <- list(
  list(name = "K4", edges = complete_graph(4), n = 4, known = 16),
  list(name = "K5", edges = complete_graph(5), n = 5, known = 125),
  list(name = "K3,3", edges = complete_bipartite(3, 3), n = 6, known = 81),
  list(name = "Cycle C6", edges = cycle_graph(6), n = 6, known = 6),
  list(name = "3 x 3 grid", edges = grid_graph(3, 3), n = 9, known = 192),
  list(name = "Petersen graph", edges = petersen_graph(), n = 10, known = 2000)
)
matrix_tree <- bind_rows(lapply(graphs, function(g) {
  tibble(graph = g$name, vertices = g$n, edges = nrow(g$edges),
         brute_force = count_trees_brute(g$edges, g$n),
         determinant = count_trees_determinant(g$edges, g$n),
         eigenvalues = count_trees_eigen(g$edges, g$n),
         textbook_value = g$known)
})) |> mutate(all_agree = brute_force == determinant & determinant == eigenvalues & eigenvalues == textbook_value)
print(matrix_tree)

random_agree <- vapply(1:30, function(i) {
  e <- random_connected_graph(6, 0.6)
  count_trees_brute(e, 6) == count_trees_determinant(e, 6) && count_trees_determinant(e, 6) == count_trees_eigen(e, 6)
}, logical(1))
cat("Random connected graphs (n = 6) where all three counts agree:", sum(random_agree), "of", length(random_agree), "\n")

cat("\n=== 4. Cayley's formula a third way: det of the reduced Laplacian of K_n ===\n")
cayley_det <- tibble(n = 2:12) |>
  rowwise() |>
  mutate(determinant = count_trees_determinant(complete_graph(n), n),
         n_pow_n_minus_2 = n^(n - 2)) |>
  ungroup() |>
  mutate(agree = determinant == n_pow_n_minus_2)
print(cayley_det)

# ---------------------------------------------------------------------
cat("\n=== 5. Degrees in a uniformly random labeled tree (n = 10) ===\n")
# Uniform tree <-> uniform Pruefer sequence (bijection), so vertex 1
# appears in each of the n - 2 slots independently with probability 1/n.
n <- 10; n_trees <- 20000
deg1 <- vapply(seq_len(n_trees), function(i) {
  s <- sample(1:n, n - 2, replace = TRUE)
  1 + sum(s == 1)                 # degree lemma: deg(1) = 1 + appearances
}, numeric(1))
degree_dist <- tibble(degree = 1:max(deg1)) |>
  mutate(empirical = vapply(degree, function(k) mean(deg1 == k), numeric(1)),
         binomial_theory = dbinom(degree - 1, n - 2, 1 / n))
print(degree_dist)
cat("Mean degree of vertex 1: empirical", round(mean(deg1), 4), " theory 2 - 2/n =", 2 - 2 / n, "\n")

# A worked example for the report (n = 8)
example_edges <- rbind(c(1, 4), c(2, 4), c(3, 5), c(4, 5), c(5, 6), c(6, 7), c(6, 8))
example_trace <- prufer_encode_trace(example_edges, 8)

saveRDS(list(prufer_check = prufer_check, enum_check = enum_check, matrix_tree = matrix_tree,
             random_agree = sum(random_agree), random_total = length(random_agree),
             cayley_det = cayley_det, degree_dist = degree_dist,
             mean_degree = mean(deg1), n_tree_degree = n,
             example_edges = example_edges, example_trace = example_trace),
        "data/clean/verification_results.rds")
