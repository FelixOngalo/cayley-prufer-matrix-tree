# Counting Trees: Cayley, Prüfer and the Matrix-Tree Theorem

**Question:** *(fill in)* How many labeled trees exist on n vertices, and how do you count spanning trees of any graph?

**Key findings:** *(fill in after running: Prüfer bijection failures (should be 0), agreement of the three counting methods, the degree experiment)*

**Tools:** R (base plus dplyr/tibble), Quarto report with complete proofs in LaTeX. Pure combinatorics and linear algebra; no graph packages.

## Why this project exists

Sixth in the pure-math series for an MSc Pure Mathematics portfolio, this time from combinatorics and graph theory. It also closes a loop with the linear-algebra project: the spectral theorem reappears in the Laplacian proof of Cayley's formula. It is directly useful for network analysis too (random trees, spanning-tree counts).

## Reproduce

1. `install.packages("tidyverse")` (needed to render the report)
2. Run `R/01_verify_theory.R` (about a minute)
3. Render `reports/report.qmd`

## Results proved

| Result | Status |
|---|---|
| Degree lemma (v appears deg(v) - 1 times in the Prüfer code) | Proved |
| Prüfer bijection, hence Cayley's formula n^(n-2) | Proved (induction) |
| Matrix-Tree theorem (Kirchhoff) | Proved, given Cauchy-Binet (cited) |
| Eigenvalue form of the tree count | Proved from the theorem |
| Cayley via the Laplacian of K_n | Proved (eigenvalues of nI - J) |
| Degree of a vertex in a random tree ~ 1 + Binomial(n-2, 1/n) | Proved |

## Verification

All sequences for n = 3..7 are decoded, checked to be trees, re-encoded, and tested against the degree lemma; every labeled tree for n = 3..6 is enumerated by brute force (independently of Cayley's formula); six named graphs (K4, K5, K3,3, C6, a 3x3 grid, the Petersen graph) and 30 random graphs are counted three ways; K_n is checked for n = 2..12.

## Project structure

```
R/graph_functions.R      union-find, Prüfer encode/decode, Laplacian, three tree counters, graph builders
R/01_verify_theory.R     exhaustive checks and the random-tree experiment
reports/report.qmd       theorems, proofs, tables, plot
```

## Limitations

- Cauchy-Binet is cited, not reproved.
- Exhaustive checks cover small cases only; the proofs cover all n.
- Simple graphs only; no tree drawings.
- *(add your own)*
